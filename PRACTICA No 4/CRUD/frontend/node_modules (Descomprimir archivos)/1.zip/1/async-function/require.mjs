import getAsyncFunction from './index.js';

export default getAsyncFunction;

export { getAsyncFunction as 'module.exports' };

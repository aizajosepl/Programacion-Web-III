'use strict';
module.exports = require('./globals.json');

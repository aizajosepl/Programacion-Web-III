"use strict";
// @ts-ignore
try {
    self['workbox:core:6.5.4'] && _();
}
catch (e) { }

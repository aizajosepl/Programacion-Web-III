"use strict";
// @ts-ignore
try {
    self['workbox:recipes:6.5.4'] && _();
}
catch (e) { }

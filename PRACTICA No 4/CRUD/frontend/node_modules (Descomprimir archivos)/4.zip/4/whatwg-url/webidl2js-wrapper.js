"use strict";

const URL = require("./dist/URL");
const URLSearchParams = require("./dist/URLSearchParams");

exports.URL = URL;
exports.URLSearchParams = URLSearchParams;

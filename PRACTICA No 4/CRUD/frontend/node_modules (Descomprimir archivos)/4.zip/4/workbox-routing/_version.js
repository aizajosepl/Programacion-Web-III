"use strict";
// @ts-ignore
try {
    self['workbox:routing:6.5.4'] && _();
}
catch (e) { }

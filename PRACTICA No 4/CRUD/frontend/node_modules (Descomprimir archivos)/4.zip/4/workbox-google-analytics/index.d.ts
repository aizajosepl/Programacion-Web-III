import { initialize, GoogleAnalyticsInitializeOptions } from './initialize.js';
import './_version.js';
/**
 * @module workbox-google-analytics
 */
export { initialize, GoogleAnalyticsInitializeOptions };
